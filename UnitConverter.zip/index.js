
// 1) select the input element and save it's value as a number

let lengthEl = document.getElementById("length-El");
let volumeEl = document.getElementById("volume-El");
let massEl = document.getElementById("mass-El");
let convertBtn = document.getElementById("convert-btn");

//2) create three function one for each of the conversions

convertBtn.addEventListener('click',calLength )

function calLength (lengthValue){

    let inputEl = document.getElementById("input-El").value;
    lengthEl.textContent = `${inputEl} meters = ${(inputEl*3.281).toFixed(2)} feet | ${inputEl} feet = ${(inputEl/3.281).toFixed(2)} meters`;
    volumeEl.textContent = `${inputEl} liters = ${(inputEl*0.264).toFixed(2)} gallons | ${inputEl} gallons = ${(inputEl/0.264).toFixed(2)} liters`;
    massEl.textContent = `${inputEl} kilos = ${(inputEl*2.204).toFixed(2)} pounds | ${inputEl} pounds = ${(inputEl/2.204).toFixed(2)} kilos`;
}

const checkbox = document.getElementById('checkbox')
checkbox.addEventListener('change', ()=>{

document.body.classList.toggle('light')
});